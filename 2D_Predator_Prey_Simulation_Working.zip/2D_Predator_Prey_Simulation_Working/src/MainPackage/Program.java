package MainPackage;


import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Sergey
 */
public class Program {

     
        public static void main(String[] args)
	{
	    UI_Grid gridForm = new UI_Grid();
            gridForm.setVisible(true);
	}
        
      
        
} 

    
    

